
#include "ssgLocal.h"


ssgStatistics _ssgCurrStatistics ;

void ssgStatistics::reset ()
{
  vertex_count = leaf_count = 0 ;
}


ssgStatistics *ssgGetLatestStatistics ()
{
  return & _ssgCurrStatistics ;
}


